package edu.ensit.pfa2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZzPlateformePfa22021Application {

	public static void main(String[] args) {
		SpringApplication.run(ZzPlateformePfa22021Application.class, args);
	}

}

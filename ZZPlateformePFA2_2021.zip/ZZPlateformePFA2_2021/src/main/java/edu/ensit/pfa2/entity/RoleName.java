package edu.ensit.pfa2.entity;

public enum RoleName {
	ROLE_CANDIDATE, ROLE_MANAGER, ROLE_ADMIN ; 
}
